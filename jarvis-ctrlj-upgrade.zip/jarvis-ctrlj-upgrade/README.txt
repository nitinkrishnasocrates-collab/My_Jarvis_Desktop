JARVIS Ctrl+J upgrade  (UI, Whisper, Piper, backend pipeline: UNTOUCHED)

INSTALL
 1. Close JARVIS completely (tray icon -> Quit JARVIS).
 2. Unzip this folder anywhere.
 3. Open Command Prompt there and run:
        APPLY.bat "C:\Users\hp\Music\JARVIS-main"      (your project folder)
    It backs up your 3 original files, copies the new ones, syntax-checks,
    and runs the 10 hotkey tests.
 4. Start JARVIS with run-app.bat as usual.

USE
 - Press Ctrl+J in ANY app (try Notepad). JARVIS appears, comes to the
   front, and the text box gets focus. Rapid repeat presses are ignored.
 - Tray icon menu shows the active hotkey and an Enable/Disable checkbox.
 - If another program owns Ctrl+J, JARVIS tells you (tray balloon + log)
   and uses Alt+J instead (then Ctrl+Alt+Shift+J).
 - Change it: edit  %APPDATA%\jarvis-app\hotkey.json
        { "enabled": true, "accelerator": "Control+J", "beep": false }
   or set env  JARVIS_HOTKEY=Control+Alt+K  (or "off").
 - Your older shortcuts still work: Ctrl+Shift+Space, Ctrl+Shift+J, Ctrl+Alt+J.

MODEL CHECK (optional, read-only)
    venv\Scripts\activate && python scripts\check_models.py

NOTE: Ctrl+J is claimed system-wide while JARVIS runs (browsers use it for
Downloads). Disable from the tray or set JARVIS_HOTKEY=off if that bothers you.

UNDO: copy files from the _backup_before_ctrlj_* folder back into electron\
 and delete electron\hotkey.cjs.
