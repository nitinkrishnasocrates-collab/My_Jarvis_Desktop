@echo off
setlocal
REM Run from inside the unzipped upgrade folder. Pass your JARVIS project path:
REM   APPLY.bat "C:\Users\hp\Music\JARVIS-main"
if "%~1"=="" (echo Usage: APPLY.bat "path\to\your\JARVIS folder" & exit /b 1)
set "T=%~1"
if not exist "%T%\electron\main.cjs" (echo [ERROR] %T%\electron\main.cjs not found & exit /b 1)
set "STAMP=%DATE:~-4%%DATE:~4,2%%DATE:~7,2%-%TIME:~0,2%%TIME:~3,2%"
set "STAMP=%STAMP: =0%"
mkdir "%T%\_backup_before_ctrlj_%STAMP%" 2>nul
copy /Y "%T%\electron\main.cjs"     "%T%\_backup_before_ctrlj_%STAMP%\" >nul
copy /Y "%T%\electron\preload.cjs"  "%T%\_backup_before_ctrlj_%STAMP%\" >nul
copy /Y "%T%\electron\package.json" "%T%\_backup_before_ctrlj_%STAMP%\" >nul
copy /Y "%~dp0electron\*.*" "%T%\electron\" >nul
if not exist "%T%\tests" mkdir "%T%\tests"
copy /Y "%~dp0tests\*.*" "%T%\tests\" >nul
if not exist "%T%\scripts" mkdir "%T%\scripts"
copy /Y "%~dp0scripts\check_models.py" "%T%\scripts\" >nul
pushd "%T%"
node --check electron\main.cjs || (echo [ERROR] syntax check failed - restoring backup & copy /Y "_backup_before_ctrlj_%STAMP%\*.*" electron\ >nul & popd & exit /b 1)
node --test tests\hotkey.test.cjs
popd
echo.
echo Applied. Backup in %T%\_backup_before_ctrlj_%STAMP%
echo Launch with run-app.bat. Press Ctrl+J from any app.
