// Run: node --test tests/hotkey.test.cjs
const test = require("node:test");
const assert = require("node:assert");
const os = require("os"), fs = require("fs"), path = require("path");
const { createHotkeyManager, FALLBACKS } = require("../electron/hotkey.cjs");

function fixture({ taken = [], settings = null } = {}) {
  const reg = new Map(); const calls = { show: 0, sent: [], focusJs: 0, onTop: [] };
  const gs = {
    register: (a, cb) => { if (taken.includes(a) || reg.has(a)) return false; reg.set(a, cb); return true; },
    unregister: (a) => reg.delete(a),
  };
  const win = {
    isDestroyed: () => false, isAlwaysOnTop: () => false,
    setAlwaysOnTop: (v) => calls.onTop.push(v), moveTop() {}, focus() {},
    webContents: { focus() {}, executeJavaScript: () => { calls.focusJs++; return Promise.resolve(true); },
                   send: (ch, p) => calls.sent.push(ch) },
  };
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "hk-"));
  const settingsPath = path.join(dir, "hotkey.json");
  if (settings) fs.writeFileSync(settingsPath, JSON.stringify(settings));
  let t = 1000;
  const m = createHotkeyManager({ globalShortcut: gs, getWindow: () => win, showWindow: () => calls.show++,
    settingsPath, log: { log() {}, warn() {} }, now: () => t });
  return { m, reg, calls, settingsPath, advance: (ms) => (t += ms) };
}

test("registers Control+J by default", () => {
  const f = fixture(); const st = f.m.start();
  assert.equal(st.state, "active"); assert.equal(st.accelerator, "Control+J"); assert.ok(f.reg.has("Control+J"));
});
test("activation shows window, focuses input, signals renderer", () => {
  const f = fixture(); f.m.start(); f.reg.get("Control+J")();
  assert.equal(f.calls.show, 1); assert.equal(f.calls.focusJs, 1);
  assert.deepEqual(f.calls.sent, ["jarvis:hotkey", "jarvis:trigger-wake"]);
});
test("rapid repeated presses are debounced (no overlapping activations)", () => {
  const f = fixture(); f.m.start(); const cb = f.reg.get("Control+J");
  cb(); cb(); cb(); assert.equal(f.calls.show, 1);
  f.advance(1000); cb(); assert.equal(f.calls.show, 2);
});
test("conflict is reported and a fallback is used", () => {
  const f = fixture({ taken: ["Control+J"] }); const st = f.m.start();
  assert.equal(st.state, "fallback"); assert.equal(st.requested, "Control+J");
  assert.equal(st.accelerator, FALLBACKS[0]); assert.match(st.message, /in use/);
});
test("total conflict is reported honestly, not faked", () => {
  const f = fixture({ taken: ["Control+J", ...FALLBACKS] }); const st = f.m.start();
  assert.equal(st.state, "conflict"); assert.equal(f.reg.size, 0);
});
test("can be disabled and re-enabled; persists to disk", () => {
  const f = fixture(); f.m.start();
  assert.equal(f.m.setEnabled(false).state, "disabled"); assert.equal(f.reg.size, 0);
  assert.equal(JSON.parse(fs.readFileSync(f.settingsPath)).enabled, false);
  assert.equal(f.m.setEnabled(true).state, "active");
});
test("custom accelerator from settings file", () => {
  const f = fixture({ settings: { accelerator: "Control+Alt+K" } }); f.m.start();
  assert.ok(f.reg.has("Control+Alt+K")); assert.ok(!f.reg.has("Control+J"));
});
test("corrupt settings fall back to defaults", () => {
  const f = fixture(); fs.writeFileSync(f.settingsPath, "{not json"); assert.equal(f.m.start().accelerator, "Control+J");
});
test("dispose releases the shortcut", () => {
  const f = fixture(); f.m.start(); f.m.dispose(); assert.equal(f.reg.size, 0);
});
test("invalid accelerator does not throw", () => {
  const f = fixture({ settings: { accelerator: "Bogus+++" } });
  const gs = { register: (a) => { if (a === "Bogus+++") throw new Error("bad"); return true; }, unregister() {} };
  const m = createHotkeyManager({ globalShortcut: gs, getWindow: () => null, showWindow() {}, settingsPath: f.settingsPath, log: { log() {}, warn() {} } });
  assert.equal(m.start().state, "fallback");
});
