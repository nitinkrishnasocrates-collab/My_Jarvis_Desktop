"""Report whether the model in config.yaml is actually installed in Ollama.
Usage (from project root, venv active):  python scripts/check_models.py
Read-only: changes nothing."""
import json, sys, urllib.request
from pathlib import Path
try:
    import yaml
except ImportError:
    sys.exit("pyyaml missing: pip install pyyaml")

cfg = yaml.safe_load(Path("config.yaml").read_text(encoding="utf-8"))
m = cfg.get("model", {})
endpoint = (m.get("endpoint") or "http://localhost:11434/v1").rstrip("/")
base = endpoint[:-3] if endpoint.endswith("/v1") else endpoint
want = m.get("model")
print(f"config model : {want}\nendpoint     : {endpoint}")
try:
    with urllib.request.urlopen(base + "/api/tags", timeout=5) as r:
        have = [x["name"] for x in json.load(r).get("models", [])]
except Exception as e:
    sys.exit(f"[FAIL] Ollama not reachable at {base}: {e}\n       Start it with:  ollama serve")
print("installed    :", ", ".join(have) or "(none)")
if want in have or f"{want}:latest" in have:
    print("[OK] configured model is installed.")
else:
    print(f"[FAIL] '{want}' is not installed. Run:  ollama pull {want}\n       or set model.model in config.yaml to one of the installed names above.")
    sys.exit(1)
if ":1.5b" in str(want) or ":0.5b" in str(want):
    print("[NOTE] this is a very small model; answers will be weak. Use a larger one your GPU/RAM can hold.")
embed = cfg.get("ultimate", {}).get("embed_model")
if embed and not any(embed in h for h in have):
    print(f"[NOTE] semantic memory embed model '{embed}' not installed (recall falls back to keywords). ollama pull {embed}")
