/**
 * J.A.R.V.I.S. — global activation hotkey (default Ctrl+J).
 *
 * Uses Electron's globalShortcut, which is backed by the Win32
 * RegisterHotKey API: no keyboard hook, no keylogging, no admin rights.
 * Only the one registered key combination is ever delivered to us.
 *
 * Behaviour on activation:
 *   - restore/show the window if hidden to tray or minimised
 *   - bring it to the foreground (Windows focus-steal workaround)
 *   - focus the existing text input (no UI changes)
 *   - emit "jarvis:trigger-wake" + "jarvis:hotkey" to the renderer
 *   - debounced, so key-repeat / rapid presses never stack activations
 *
 * Settings live in <userData>/hotkey.json:
 *   { "enabled": true, "accelerator": "Control+J", "beep": false }
 * Env override: JARVIS_HOTKEY="Control+Alt+J", JARVIS_HOTKEY=off
 */
const fs = require("fs");
const path = require("path");

const DEFAULTS = { enabled: true, accelerator: "Control+J", beep: false };
const FALLBACKS = ["Alt+J", "Control+Alt+Shift+J"];
const DEBOUNCE_MS = 450;

const FOCUS_INPUT_JS = `(() => {
  try {
    const el = document.querySelector('textarea, input[type="text"], input:not([type]), [contenteditable="true"]');
    if (el && typeof el.focus === 'function') { el.focus(); return true; }
  } catch (e) {}
  return false;
})()`;

function createHotkeyManager({ globalShortcut, getWindow, showWindow, settingsPath, shell, log = console, now = Date.now }) {
  let settings = { ...DEFAULTS };
  let active = null;          // accelerator currently registered, or null
  let lastActivation = 0;
  let status = { state: "off", accelerator: null, message: "not started" };

  function load() {
    try {
      const j = JSON.parse(fs.readFileSync(settingsPath, "utf-8"));
      if (j && typeof j === "object") settings = { ...DEFAULTS, ...j };
    } catch { /* missing or corrupt -> defaults */ }
    const env = (process.env.JARVIS_HOTKEY || "").trim();
    if (env) {
      if (/^(off|0|false|none)$/i.test(env)) settings.enabled = false;
      else settings.accelerator = env;
    }
  }

  function save() {
    try {
      fs.mkdirSync(path.dirname(settingsPath), { recursive: true });
      fs.writeFileSync(settingsPath, JSON.stringify(settings, null, 2));
    } catch (e) { log.warn("[hotkey] could not save settings:", e.message); }
  }

  function tryRegister(accel) {
    try {
      return globalShortcut.register(accel, activate) === true;
    } catch (e) {
      log.warn(`[hotkey] invalid accelerator "${accel}":`, e.message);
      return false;
    }
  }

  function unregister() {
    if (active) {
      try { globalShortcut.unregister(active); } catch { /* ignore */ }
      active = null;
    }
  }

  /** (Re)register according to current settings. Never throws. */
  function apply() {
    unregister();
    if (!settings.enabled) {
      status = { state: "disabled", accelerator: settings.accelerator, message: "disabled in settings" };
      return status;
    }
    const wanted = settings.accelerator;
    if (tryRegister(wanted)) {
      active = wanted;
      status = { state: "active", accelerator: wanted, message: `${wanted} is active` };
      log.log("[hotkey]", status.message);
      return status;
    }
    // Another app (or this one) already owns it. Report it, then try fallbacks.
    log.warn(`[hotkey] ${wanted} could not be registered — likely owned by another application`);
    for (const alt of FALLBACKS) {
      if (alt !== wanted && tryRegister(alt)) {
        active = alt;
        status = {
          state: "fallback", accelerator: alt, requested: wanted,
          message: `${wanted} is in use by another application; using ${alt} instead`,
        };
        log.warn("[hotkey]", status.message);
        return status;
      }
    }
    status = {
      state: "conflict", accelerator: null, requested: wanted,
      message: `${wanted} is in use by another application and no fallback was free. Edit hotkey.json to choose another.`,
    };
    log.warn("[hotkey]", status.message);
    return status;
  }

  function activate() {
    const t = now();
    if (t - lastActivation < DEBOUNCE_MS) return false;   // key-repeat / double press
    lastActivation = t;
    try {
      showWindow();
      const win = getWindow();
      if (!win || win.isDestroyed()) return false;
      // Windows may refuse focus to a background process; a momentary
      // always-on-top promotion reliably brings the window forward.
      const wasOnTop = win.isAlwaysOnTop();
      if (!wasOnTop) {
        win.setAlwaysOnTop(true, "screen-saver");
        win.moveTop();
        win.focus();
        setTimeout(() => { try { if (!win.isDestroyed()) win.setAlwaysOnTop(false); } catch { /* */ } }, 250);
      } else {
        win.moveTop(); win.focus();
      }
      const wc = win.webContents;
      wc.focus();
      wc.executeJavaScript(FOCUS_INPUT_JS).catch(() => {});
      try { wc.send("jarvis:hotkey", { accelerator: active, at: t }); } catch { /* */ }
      try { wc.send("jarvis:trigger-wake", { source: "hotkey" }); } catch { /* */ }
      if (settings.beep && shell && shell.beep) shell.beep();
      return true;
    } catch (e) {
      log.warn("[hotkey] activation failed:", e.message);
      return false;
    }
  }

  return {
    start() { load(); return apply(); },
    activate,
    getStatus: () => ({ ...status, enabled: settings.enabled }),
    isEnabled: () => settings.enabled,
    setEnabled(on) { settings.enabled = !!on; save(); return apply(); },
    setAccelerator(accel) { settings.accelerator = String(accel); save(); return apply(); },
    dispose() { unregister(); },
  };
}

module.exports = { createHotkeyManager, DEFAULTS, FALLBACKS, DEBOUNCE_MS };
