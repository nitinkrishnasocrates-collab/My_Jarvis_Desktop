/**
 * J.A.R.V.I.S. — auto-start the wake-word mic on launch.
 *
 * The UI only begins listening for "Hey JARVIS" after the mic button is
 * clicked. This clicks that same button once per page load (when its tooltip
 * says "Start listening"). It never opens the mic itself; the existing
 * pipeline does, so there is still exactly one audio loop.
 *
 * Disable with env JARVIS_AUTOMIC=off
 */
const CLICK_JS = `(() => {
  try {
    const btns = [...document.querySelectorAll('button[title]')];
    const off = btns.find(b => b.title === 'Start listening');
    if (off) { off.click(); return 'clicked'; }
    if (btns.some(b => /^mic /.test(b.title))) return 'already-on';
  } catch (e) {}
  return 'no-button';
})()`;

function attachAutoMic(win, { log = console, delayMs = 2500, pollMs = 1000, maxMs = 45000 } = {}) {
  if (/^(off|0|false|none)$/i.test((process.env.JARVIS_AUTOMIC || "").trim())) {
    log.log("[automic] disabled by JARVIS_AUTOMIC");
    return { cancel() {} };
  }
  const wc = win.webContents;
  let token = 0;

  async function run(my) {
    const started = Date.now();
    await new Promise((r) => setTimeout(r, delayMs));          // let the UI hydrate
    while (my === token && Date.now() - started < maxMs) {
      if (win.isDestroyed()) return;
      let res = "no-button";
      try { res = await wc.executeJavaScript(CLICK_JS); } catch { /* page not ready */ }
      if (res === "clicked" || res === "already-on") {
        log.log("[automic] wake-word mic:", res);
        return res;
      }
      await new Promise((r) => setTimeout(r, pollMs));
    }
    if (my === token) log.warn("[automic] mic button not found; click it manually once");
  }

  wc.on("did-finish-load", () => {
    const url = (() => { try { return wc.getURL(); } catch { return ""; } })();
    if (!/^https?:\/\/(127\.0\.0\.1|localhost)/.test(url)) return;   // skip error page
    run(++token);
  });
  return { cancel() { token++; }, _run: () => run(++token) };
}

module.exports = { attachAutoMic, CLICK_JS };
