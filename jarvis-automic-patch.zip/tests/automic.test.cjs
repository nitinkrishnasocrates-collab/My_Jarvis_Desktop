// Run: node --test tests/automic.test.cjs
const test = require("node:test"); const assert = require("node:assert");
const { attachAutoMic } = require("../electron/automic.cjs");
function mk(results, url = "http://127.0.0.1:7341/") {
  let handler; const calls = { js: 0 };
  const wc = { on: (e, f) => { if (e === "did-finish-load") handler = f; }, getURL: () => url,
    executeJavaScript: async () => { calls.js++; const r = results.shift(); if (r instanceof Error) throw r; return r ?? "no-button"; } };
  const win = { webContents: wc, isDestroyed: () => false };
  return { win, fire: () => handler(), calls };
}
const quiet = { log() {}, warn() {} };
test("clicks the mic once when button says Start listening", async () => {
  const m = mk(["clicked"]); const h = attachAutoMic(m.win, { log: quiet, delayMs: 1, pollMs: 1 });
  assert.equal(await h._run(), "clicked"); assert.equal(m.calls.js, 1);
});
test("retries until the UI has rendered the button", async () => {
  const m = mk(["no-button", new Error("not ready"), "clicked"]);
  const h = attachAutoMic(m.win, { log: quiet, delayMs: 1, pollMs: 1 });
  assert.equal(await h._run(), "clicked"); assert.equal(m.calls.js, 3);
});
test("does not toggle the mic off if already listening", async () => {
  const m = mk(["already-on"]); const h = attachAutoMic(m.win, { log: quiet, delayMs: 1, pollMs: 1 });
  assert.equal(await h._run(), "already-on");
});
test("gives up cleanly after maxMs", async () => {
  const m = mk([]); const h = attachAutoMic(m.win, { log: quiet, delayMs: 1, pollMs: 5, maxMs: 30 });
  assert.equal(await h._run(), undefined);
});
test("ignores the backend-down error page", async () => {
  const m = mk(["clicked"], "data:text/html,x"); attachAutoMic(m.win, { log: quiet, delayMs: 1, pollMs: 1 });
  m.fire(); await new Promise(r => setTimeout(r, 30)); assert.equal(m.calls.js, 0);
});
test("env switch disables it", () => {
  process.env.JARVIS_AUTOMIC = "off"; const m = mk([]); attachAutoMic(m.win, { log: quiet });
  assert.equal(m.fire, m.fire); delete process.env.JARVIS_AUTOMIC;
});
